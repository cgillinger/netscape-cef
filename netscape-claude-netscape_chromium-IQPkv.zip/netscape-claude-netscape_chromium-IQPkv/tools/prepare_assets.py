#!/usr/bin/env python3
"""
Netscape CEF Asset Preparation Tool

Converts original Netscape GIF/BMP/XPM assets to PNG format
and organizes them for the CEF browser project.
"""

import os
import sys
import shutil
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("ERROR: Pillow library required. Install with: pip install Pillow")
    sys.exit(1)


# Asset mapping: source filename -> target path
ASSET_MAPPING = {
    # Toolbar buttons
    "TB_Back.gif": "toolbar/TB_Back.png",
    "TB_Back.mo.gif": "toolbar/TB_Back.mo.png",
    "TB_Back.md.gif": "toolbar/TB_Back.md.png",
    "TB_Back.i.gif": "toolbar/TB_Back.i.png",

    "TB_Forward.gif": "toolbar/TB_Forward.png",
    "TB_Forward.mo.gif": "toolbar/TB_Forward.mo.png",
    "TB_Forward.md.gif": "toolbar/TB_Forward.md.png",
    "TB_Forward.i.gif": "toolbar/TB_Forward.i.png",

    "TB_Reload.gif": "toolbar/TB_Reload.png",
    "TB_Reload.mo.gif": "toolbar/TB_Reload.mo.png",
    "TB_Reload.md.gif": "toolbar/TB_Reload.md.png",
    "TB_Reload.i.gif": "toolbar/TB_Reload.i.png",

    "TB_Stop.gif": "toolbar/TB_Stop.png",
    "TB_Stop.mo.gif": "toolbar/TB_Stop.mo.png",
    "TB_Stop.md.gif": "toolbar/TB_Stop.md.png",
    "TB_Stop.i.gif": "toolbar/TB_Stop.i.png",

    "TB_Home.gif": "toolbar/TB_Home.png",
    "TB_Home.mo.gif": "toolbar/TB_Home.mo.png",
    "TB_Home.md.gif": "toolbar/TB_Home.md.png",
    "TB_Home.i.gif": "toolbar/TB_Home.i.png",

    "TB_Search.gif": "toolbar/TB_Search.png",
    "TB_Search.mo.gif": "toolbar/TB_Search.mo.png",
    "TB_Search.md.gif": "toolbar/TB_Search.md.png",
    "TB_Search.i.gif": "toolbar/TB_Search.i.png",

    "TB_Print.gif": "toolbar/TB_Print.png",
    "TB_Print.mo.gif": "toolbar/TB_Print.mo.png",
    "TB_Print.md.gif": "toolbar/TB_Print.md.png",
    "TB_Print.i.gif": "toolbar/TB_Print.i.png",

    "TB_Secure.gif": "toolbar/TB_Secure.png",
    "TB_Secure.mo.gif": "toolbar/TB_Secure.mo.png",
    "TB_Secure.md.gif": "toolbar/TB_Secure.md.png",

    "TB_Unsecure.gif": "toolbar/TB_Unsecure.png",
    "TB_MixSecurity.gif": "toolbar/TB_MixSecurity.png",

    # Security icons for status bar
    "Dash_Secure.gif": "icons/Dash_Secure.png",
    "Dash_Unsecure.gif": "icons/Dash_Unsecure.png",
    "Dash_MixSecurity.gif": "icons/Dash_MixSecurity.png",

    # Bookmark icons
    "BM_Bookmark.gif": "icons/BM_Bookmark.png",
    "BM_Folder.gif": "icons/BM_Folder.png",
    "BM_FolderO.gif": "icons/BM_FolderO.png",
}

# Throbber animation frames
for i in range(30):
    frame_name = f"AnimHuge{i:02d}.gif"
    ASSET_MAPPING[frame_name] = f"throbber/AnimHuge{i:02d}.png"


def convert_image(src_path: Path, dst_path: Path):
    """Convert image to PNG format, handling transparency."""
    try:
        img = Image.open(src_path)

        # Handle palette-based transparency
        if img.mode == 'P':
            img = img.convert('RGBA')
        elif img.mode != 'RGBA':
            img = img.convert('RGBA')

        # Ensure destination directory exists
        dst_path.parent.mkdir(parents=True, exist_ok=True)

        # Save as PNG
        img.save(dst_path, 'PNG')
        return True

    except Exception as e:
        print(f"  ERROR converting {src_path}: {e}")
        return False


def find_asset(source_dirs: list, filename: str) -> Path:
    """Find an asset file in the source directories."""
    for src_dir in source_dirs:
        # Try exact match
        path = src_dir / filename
        if path.exists():
            return path

        # Try case-insensitive search
        for f in src_dir.iterdir():
            if f.name.lower() == filename.lower():
                return f

    return None


def prepare_assets(source_dirs: list, output_dir: Path):
    """Prepare all assets for the project."""
    output_1x = output_dir / "1x"
    output_1x.mkdir(parents=True, exist_ok=True)

    converted = 0
    missing = 0

    print(f"\nPreparing assets...")
    print(f"Source directories: {[str(d) for d in source_dirs]}")
    print(f"Output directory: {output_dir}\n")

    for src_name, dst_name in ASSET_MAPPING.items():
        src_path = find_asset(source_dirs, src_name)

        if src_path:
            dst_path = output_1x / dst_name
            if convert_image(src_path, dst_path):
                print(f"  ✓ {src_name} -> {dst_name}")
                converted += 1
            else:
                missing += 1
        else:
            print(f"  ✗ {src_name} (not found)")
            missing += 1

    print(f"\nConverted: {converted}")
    print(f"Missing: {missing}")

    return converted, missing


def main():
    # Determine paths
    script_dir = Path(__file__).parent
    project_dir = script_dir.parent
    output_dir = project_dir / "assets"

    # Source directories to search
    source_dirs = [
        project_dir.parent / "resources_claude",  # Our collected resources
        project_dir.parent / "cmd" / "xfe" / "icons" / "images",
        project_dir.parent / "cmd" / "winfe" / "res",
    ]

    # Filter to existing directories
    source_dirs = [d for d in source_dirs if d.exists()]

    if not source_dirs:
        print("ERROR: No source asset directories found!")
        print("Expected resources at: ../resources_claude/")
        sys.exit(1)

    converted, missing = prepare_assets(source_dirs, output_dir)

    if missing > 0:
        print("\nWARNING: Some assets were not found.")
        print("The browser will use placeholder graphics for missing assets.")

    print("\nAsset preparation complete!")
    print(f"Assets saved to: {output_dir}/1x/")


if __name__ == "__main__":
    main()
