#!/usr/bin/env python3
"""
Asset Scaling Tool for HiDPI Displays

Scales 1x assets to 2x or 3x using nearest-neighbor interpolation
to preserve pixel-perfect appearance of classic graphics.
"""

import argparse
import os
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("ERROR: Pillow library required. Install with: pip install Pillow")
    exit(1)


def scale_image_nearest(input_path: Path, output_path: Path, scale: int):
    """Scale image using nearest-neighbor interpolation."""
    try:
        img = Image.open(input_path)

        # Calculate new size
        new_size = (img.width * scale, img.height * scale)

        # Scale with nearest neighbor (preserves pixel art)
        scaled = img.resize(new_size, Image.NEAREST)

        # Ensure output directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Save
        scaled.save(output_path, 'PNG')
        return True

    except Exception as e:
        print(f"  ERROR: {input_path}: {e}")
        return False


def process_directory(input_dir: Path, output_dir: Path, scale: int):
    """Process all PNG images in directory recursively."""
    count = 0
    errors = 0

    for input_path in input_dir.rglob("*.png"):
        # Calculate relative path
        rel_path = input_path.relative_to(input_dir)
        output_path = output_dir / rel_path

        if scale_image_nearest(input_path, output_path, scale):
            print(f"  {rel_path} -> {scale}x")
            count += 1
        else:
            errors += 1

    return count, errors


def main():
    parser = argparse.ArgumentParser(
        description="Scale assets for HiDPI displays"
    )
    parser.add_argument(
        "--input", "-i",
        required=True,
        help="Input directory containing 1x assets"
    )
    parser.add_argument(
        "--output", "-o",
        required=True,
        help="Output directory for scaled assets"
    )
    parser.add_argument(
        "--scale", "-s",
        type=int,
        choices=[2, 3],
        required=True,
        help="Scale factor (2 or 3)"
    )

    args = parser.parse_args()

    input_dir = Path(args.input)
    output_dir = Path(args.output)
    scale = args.scale

    if not input_dir.exists():
        print(f"ERROR: Input directory does not exist: {input_dir}")
        return 1

    print(f"Scaling assets to {scale}x...")
    print(f"Input: {input_dir}")
    print(f"Output: {output_dir}")
    print()

    count, errors = process_directory(input_dir, output_dir, scale)

    print()
    print(f"Scaled: {count} images")
    if errors:
        print(f"Errors: {errors}")

    return 0 if errors == 0 else 1


if __name__ == "__main__":
    exit(main())
