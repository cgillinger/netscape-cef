#ifndef NETSCAPE_CLIENT_H
#define NETSCAPE_CLIENT_H

#include "include/cef_client.h"
#include "NetscapeLoadHandler.h"
#include "NetscapeDisplayHandler.h"
#include "NetscapeRequestHandler.h"

class NetscapeMainWindow;

/**
 * CEF Client implementation
 * Routes CEF callbacks to appropriate handlers
 */
class NetscapeClient : public CefClient {
public:
    explicit NetscapeClient(NetscapeMainWindow* window);

    // Handler accessors
    CefRefPtr<CefDisplayHandler> GetDisplayHandler() override {
        return m_displayHandler;
    }

    CefRefPtr<CefLoadHandler> GetLoadHandler() override {
        return m_loadHandler;
    }

    CefRefPtr<CefRequestHandler> GetRequestHandler() override {
        return m_requestHandler;
    }

    CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override {
        return nullptr; // Use default
    }

private:
    CefRefPtr<NetscapeLoadHandler> m_loadHandler;
    CefRefPtr<NetscapeDisplayHandler> m_displayHandler;
    CefRefPtr<NetscapeRequestHandler> m_requestHandler;

    IMPLEMENT_REFCOUNTING(NetscapeClient);
    DISALLOW_COPY_AND_ASSIGN(NetscapeClient);
};

#endif // NETSCAPE_CLIENT_H
