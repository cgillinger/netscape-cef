#include "CefBrowserWidget.h"
#include "ui/NetscapeMainWindow.h"

#include <QResizeEvent>
#include <QShowEvent>
#include <QCloseEvent>

#include "include/cef_browser.h"
#include "include/cef_client.h"

#ifdef Q_OS_LINUX
#include <QX11Info>
#endif

CefBrowserWidget::CefBrowserWidget(NetscapeMainWindow* mainWindow, QWidget* parent)
    : QWidget(parent)
    , m_mainWindow(mainWindow) {

    // Set attributes for CEF embedding
    setAttribute(Qt::WA_NativeWindow);
    setAttribute(Qt::WA_OpaquePaintEvent);
    setAttribute(Qt::WA_NoSystemBackground);

    // Create CEF client
    m_client = new NetscapeClient(mainWindow);
}

CefBrowserWidget::~CefBrowserWidget() {
    closeBrowser();
}

void CefBrowserWidget::createBrowser(const QString& url) {
    if (m_browserCreated) {
        loadUrl(url);
        return;
    }

    // Store URL if window not yet visible
    if (!isVisible()) {
        m_pendingUrl = url;
        return;
    }

    CefWindowInfo windowInfo;

#ifdef Q_OS_LINUX
    // Get X11 window handle
    windowInfo.SetAsChild(winId(), CefRect(0, 0, width(), height()));
#endif

#ifdef Q_OS_WIN
    HWND hwnd = (HWND)winId();
    RECT rect;
    GetClientRect(hwnd, &rect);
    windowInfo.SetAsChild(hwnd, rect);
#endif

#ifdef Q_OS_MAC
    windowInfo.SetAsChild((CefWindowHandle)winId(), 0, 0, width(), height());
#endif

    CefBrowserSettings browserSettings;

    // Classic browser behavior settings
    browserSettings.javascript_access_clipboard = STATE_DISABLED;
    browserSettings.local_storage = STATE_ENABLED;
    browserSettings.databases = STATE_ENABLED;

    // Create browser synchronously
    m_browser = CefBrowserHost::CreateBrowserSync(
        windowInfo,
        m_client.get(),
        url.toStdString(),
        browserSettings,
        nullptr,
        nullptr
    );

    if (m_browser) {
        m_browserCreated = true;
        emit browserCreated();
    }
}

void CefBrowserWidget::closeBrowser() {
    if (m_browser) {
        m_browser->GetHost()->CloseBrowser(true);
        m_browser = nullptr;
        m_browserCreated = false;
        emit browserClosed();
    }
}

void CefBrowserWidget::loadUrl(const QString& url) {
    if (m_browser) {
        m_browser->GetMainFrame()->LoadURL(url.toStdString());
    } else {
        m_pendingUrl = url;
    }
}

void CefBrowserWidget::goBack() {
    if (m_browser && m_browser->CanGoBack()) {
        m_browser->GoBack();
    }
}

void CefBrowserWidget::goForward() {
    if (m_browser && m_browser->CanGoForward()) {
        m_browser->GoForward();
    }
}

void CefBrowserWidget::reload() {
    if (m_browser) {
        m_browser->Reload();
    }
}

void CefBrowserWidget::stopLoad() {
    if (m_browser) {
        m_browser->StopLoad();
    }
}

bool CefBrowserWidget::canGoBack() const {
    return m_browser && m_browser->CanGoBack();
}

bool CefBrowserWidget::canGoForward() const {
    return m_browser && m_browser->CanGoForward();
}

bool CefBrowserWidget::isLoading() const {
    return m_browser && m_browser->IsLoading();
}

void CefBrowserWidget::resizeEvent(QResizeEvent* event) {
    QWidget::resizeEvent(event);
    updateBrowserSize();
}

void CefBrowserWidget::showEvent(QShowEvent* event) {
    QWidget::showEvent(event);

    if (!m_browserCreated && !m_pendingUrl.isEmpty()) {
        createBrowser(m_pendingUrl);
        m_pendingUrl.clear();
    }
}

void CefBrowserWidget::closeEvent(QCloseEvent* event) {
    closeBrowser();
    QWidget::closeEvent(event);
}

void CefBrowserWidget::updateBrowserSize() {
    if (!m_browser) return;

#ifdef Q_OS_LINUX
    // Notify CEF of size change
    m_browser->GetHost()->WasResized();
#endif

#ifdef Q_OS_WIN
    HWND browserHwnd = m_browser->GetHost()->GetWindowHandle();
    if (browserHwnd) {
        SetWindowPos(browserHwnd, nullptr, 0, 0, width(), height(),
                     SWP_NOZORDER | SWP_NOMOVE);
    }
#endif
}
