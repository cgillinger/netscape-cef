#ifndef NETSCAPE_LOAD_HANDLER_H
#define NETSCAPE_LOAD_HANDLER_H

#include <QPointer>
#include "include/cef_load_handler.h"

class NetscapeMainWindow;

/**
 * Handles page loading events
 * Updates throbber, progress bar, status text
 */
class NetscapeLoadHandler : public CefLoadHandler {
public:
    explicit NetscapeLoadHandler(NetscapeMainWindow* window);

    // Loading state changes
    void OnLoadingStateChange(CefRefPtr<CefBrowser> browser,
                              bool isLoading,
                              bool canGoBack,
                              bool canGoForward) override;

    // Load started
    void OnLoadStart(CefRefPtr<CefBrowser> browser,
                     CefRefPtr<CefFrame> frame,
                     TransitionType transition_type) override;

    // Load completed
    void OnLoadEnd(CefRefPtr<CefBrowser> browser,
                   CefRefPtr<CefFrame> frame,
                   int httpStatusCode) override;

    // Load error
    void OnLoadError(CefRefPtr<CefBrowser> browser,
                     CefRefPtr<CefFrame> frame,
                     ErrorCode errorCode,
                     const CefString& errorText,
                     const CefString& failedUrl) override;

private:
    QString generateErrorPage(const QString& errorText, const QString& url);

    QPointer<NetscapeMainWindow> m_window;

    IMPLEMENT_REFCOUNTING(NetscapeLoadHandler);
    DISALLOW_COPY_AND_ASSIGN(NetscapeLoadHandler);
};

#endif // NETSCAPE_LOAD_HANDLER_H
