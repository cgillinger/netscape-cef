#include "NetscapeRequestHandler.h"
#include "ui/NetscapeMainWindow.h"

#include <QMetaObject>
#include <QMessageBox>

NetscapeRequestHandler::NetscapeRequestHandler(NetscapeMainWindow* window)
    : m_window(window) {
}

bool NetscapeRequestHandler::OnCertificateError(
    CefRefPtr<CefBrowser> browser,
    cef_errorcode_t cert_error,
    const CefString& request_url,
    CefRefPtr<CefSSLInfo> ssl_info,
    CefRefPtr<CefCallback> callback) {

    if (!m_window) {
        callback->Cancel();
        return true;
    }

    QString url = QString::fromStdString(request_url.ToString());

    // Update security state
    QMetaObject::invokeMethod(m_window, [=]() {
        m_window->setSecurityState(NetscapeMainWindow::SecurityState::CertError);

        // Show classic-style security warning dialog
        QMessageBox msgBox(m_window);
        msgBox.setWindowTitle("Security Warning");
        msgBox.setIcon(QMessageBox::Warning);
        msgBox.setText(QString(
            "<h3>Security Alert</h3>"
            "<p>Netscape has detected that the server <b>%1</b> "
            "has an invalid or expired security certificate.</p>"
            "<p>You can choose to continue anyway, but this may put "
            "your information at risk.</p>"
        ).arg(QUrl(url).host()));

        msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        msgBox.setDefaultButton(QMessageBox::No);
        msgBox.button(QMessageBox::Yes)->setText("Continue Anyway");
        msgBox.button(QMessageBox::No)->setText("Go Back");

        if (msgBox.exec() == QMessageBox::Yes) {
            callback->Continue();
        } else {
            callback->Cancel();
        }
    }, Qt::BlockingQueuedConnection);

    return true;
}

bool NetscapeRequestHandler::OnBeforeBrowse(
    CefRefPtr<CefBrowser> browser,
    CefRefPtr<CefFrame> frame,
    CefRefPtr<CefRequest> request,
    bool user_gesture,
    bool is_redirect) {

    // Allow all navigation
    return false;
}
