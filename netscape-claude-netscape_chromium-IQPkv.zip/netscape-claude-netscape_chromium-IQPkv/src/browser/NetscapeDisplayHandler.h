#ifndef NETSCAPE_DISPLAY_HANDLER_H
#define NETSCAPE_DISPLAY_HANDLER_H

#include <QPointer>
#include "include/cef_display_handler.h"

class NetscapeMainWindow;

/**
 * Handles display-related events
 * Updates address bar, title, status bar
 */
class NetscapeDisplayHandler : public CefDisplayHandler {
public:
    explicit NetscapeDisplayHandler(NetscapeMainWindow* window);

    // Address changed
    void OnAddressChange(CefRefPtr<CefBrowser> browser,
                         CefRefPtr<CefFrame> frame,
                         const CefString& url) override;

    // Title changed
    void OnTitleChange(CefRefPtr<CefBrowser> browser,
                       const CefString& title) override;

    // Status message (link hover)
    void OnStatusMessage(CefRefPtr<CefBrowser> browser,
                         const CefString& value) override;

    // Console messages (suppress)
    bool OnConsoleMessage(CefRefPtr<CefBrowser> browser,
                          cef_log_severity_t level,
                          const CefString& message,
                          const CefString& source,
                          int line) override;

    // Favicon changed
    void OnFaviconURLChange(CefRefPtr<CefBrowser> browser,
                            const std::vector<CefString>& icon_urls) override;

private:
    QPointer<NetscapeMainWindow> m_window;

    IMPLEMENT_REFCOUNTING(NetscapeDisplayHandler);
    DISALLOW_COPY_AND_ASSIGN(NetscapeDisplayHandler);
};

#endif // NETSCAPE_DISPLAY_HANDLER_H
