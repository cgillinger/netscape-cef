#include "NetscapeClient.h"
#include "ui/NetscapeMainWindow.h"

NetscapeClient::NetscapeClient(NetscapeMainWindow* window) {
    m_loadHandler = new NetscapeLoadHandler(window);
    m_displayHandler = new NetscapeDisplayHandler(window);
    m_requestHandler = new NetscapeRequestHandler(window);
}
