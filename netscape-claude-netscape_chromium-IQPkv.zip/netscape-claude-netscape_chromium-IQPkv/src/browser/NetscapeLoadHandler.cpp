#include "NetscapeLoadHandler.h"
#include "ui/NetscapeMainWindow.h"

#include <QMetaObject>
#include <QUrl>

NetscapeLoadHandler::NetscapeLoadHandler(NetscapeMainWindow* window)
    : m_window(window) {
}

void NetscapeLoadHandler::OnLoadingStateChange(
    CefRefPtr<CefBrowser> browser,
    bool isLoading,
    bool canGoBack,
    bool canGoForward) {

    if (!m_window) return;

    // Marshal to Qt thread
    QMetaObject::invokeMethod(m_window, [=]() {
        // Update throbber
        if (isLoading) {
            m_window->startThrobber();
        } else {
            m_window->stopThrobber();
        }

        // Update navigation buttons
        m_window->setBackEnabled(canGoBack);
        m_window->setForwardEnabled(canGoForward);

        // Toggle stop/reload button
        m_window->setStopVisible(isLoading);
        m_window->setReloadVisible(!isLoading);

    }, Qt::QueuedConnection);
}

void NetscapeLoadHandler::OnLoadStart(
    CefRefPtr<CefBrowser> browser,
    CefRefPtr<CefFrame> frame,
    TransitionType transition_type) {

    if (!m_window || !frame->IsMain()) return;

    QMetaObject::invokeMethod(m_window, [=]() {
        m_window->setStatusText("Connecting...");
        m_window->showProgress(true);
        m_window->setProgress(0);
    }, Qt::QueuedConnection);
}

void NetscapeLoadHandler::OnLoadEnd(
    CefRefPtr<CefBrowser> browser,
    CefRefPtr<CefFrame> frame,
    int httpStatusCode) {

    if (!m_window || !frame->IsMain()) return;

    QMetaObject::invokeMethod(m_window, [=]() {
        m_window->setStatusText("Document: Done");
        m_window->showProgress(false);
    }, Qt::QueuedConnection);
}

void NetscapeLoadHandler::OnLoadError(
    CefRefPtr<CefBrowser> browser,
    CefRefPtr<CefFrame> frame,
    ErrorCode errorCode,
    const CefString& errorText,
    const CefString& failedUrl) {

    if (!m_window || !frame->IsMain()) return;

    // Don't show error for aborted loads
    if (errorCode == ERR_ABORTED) return;

    QString error = QString::fromStdString(errorText.ToString());
    QString url = QString::fromStdString(failedUrl.ToString());
    QString errorPage = generateErrorPage(error, url);

    // Load error page
    std::string dataUrl = "data:text/html;charset=utf-8," +
        QUrl::toPercentEncoding(errorPage).toStdString();
    frame->LoadURL(dataUrl);

    QMetaObject::invokeMethod(m_window, [=]() {
        m_window->setStatusText("Error loading page");
    }, Qt::QueuedConnection);
}

QString NetscapeLoadHandler::generateErrorPage(const QString& errorText,
                                                const QString& url) {
    // Classic Netscape-style error page
    return QString(R"HTML(
<!DOCTYPE html>
<html>
<head>
    <title>Netscape: Unable to locate server</title>
    <style>
        body {
            font-family: 'Times New Roman', serif;
            background-color: #c0c0c0;
            margin: 40px;
        }
        h1 {
            color: #000080;
            font-size: 24px;
            border-bottom: 2px solid #000080;
            padding-bottom: 10px;
        }
        .error-box {
            background-color: #ffffff;
            border: 2px inset #808080;
            padding: 20px;
            margin: 20px 0;
        }
        .url {
            font-family: monospace;
            background-color: #ffffc0;
            padding: 2px 5px;
        }
        ul {
            margin-top: 20px;
        }
        li {
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <h1>Netscape is unable to locate the server</h1>

    <div class="error-box">
        <p><strong>The server at</strong> <span class="url">%1</span> <strong>could not be found.</strong></p>
        <p>Error: %2</p>
    </div>

    <p>Please check the following:</p>
    <ul>
        <li>Check the URL for typing errors such as <strong>ww.example.com</strong> instead of <strong>www.example.com</strong></li>
        <li>If you are unable to load any pages, check your computer's network connection.</li>
        <li>If your computer or network is protected by a firewall or proxy, make sure that the browser is permitted to access the Web.</li>
    </ul>
</body>
</html>
)HTML").arg(url.toHtmlEscaped(), errorText.toHtmlEscaped());
}
