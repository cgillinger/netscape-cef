#ifndef NETSCAPE_REQUEST_HANDLER_H
#define NETSCAPE_REQUEST_HANDLER_H

#include <QPointer>
#include "include/cef_request_handler.h"

class NetscapeMainWindow;

/**
 * Handles request-related events
 * Security certificates, authentication, etc.
 */
class NetscapeRequestHandler : public CefRequestHandler {
public:
    explicit NetscapeRequestHandler(NetscapeMainWindow* window);

    // Certificate error handling
    bool OnCertificateError(CefRefPtr<CefBrowser> browser,
                            cef_errorcode_t cert_error,
                            const CefString& request_url,
                            CefRefPtr<CefSSLInfo> ssl_info,
                            CefRefPtr<CefCallback> callback) override;

    // Before navigation
    bool OnBeforeBrowse(CefRefPtr<CefBrowser> browser,
                        CefRefPtr<CefFrame> frame,
                        CefRefPtr<CefRequest> request,
                        bool user_gesture,
                        bool is_redirect) override;

private:
    QPointer<NetscapeMainWindow> m_window;

    IMPLEMENT_REFCOUNTING(NetscapeRequestHandler);
    DISALLOW_COPY_AND_ASSIGN(NetscapeRequestHandler);
};

#endif // NETSCAPE_REQUEST_HANDLER_H
