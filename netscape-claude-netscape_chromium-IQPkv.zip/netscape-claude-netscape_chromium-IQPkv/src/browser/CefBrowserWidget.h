#ifndef CEF_BROWSER_WIDGET_H
#define CEF_BROWSER_WIDGET_H

#include <QWidget>
#include <QPointer>
#include "include/cef_browser.h"
#include "NetscapeClient.h"

class NetscapeMainWindow;

/**
 * Qt widget that hosts the CEF browser view
 * Handles window embedding and resize events
 */
class CefBrowserWidget : public QWidget {
    Q_OBJECT

public:
    explicit CefBrowserWidget(NetscapeMainWindow* mainWindow, QWidget* parent = nullptr);
    ~CefBrowserWidget() override;

    // Browser control
    void createBrowser(const QString& url);
    void closeBrowser();

    // Navigation
    void loadUrl(const QString& url);
    void goBack();
    void goForward();
    void reload();
    void stopLoad();

    // State queries
    bool canGoBack() const;
    bool canGoForward() const;
    bool isLoading() const;

    // Get browser instance
    CefRefPtr<CefBrowser> getBrowser() const { return m_browser; }

signals:
    void browserCreated();
    void browserClosed();

protected:
    void resizeEvent(QResizeEvent* event) override;
    void showEvent(QShowEvent* event) override;
    void closeEvent(QCloseEvent* event) override;

    // Disable Qt painting - CEF handles rendering
    QPaintEngine* paintEngine() const override { return nullptr; }

private:
    void updateBrowserSize();

    CefRefPtr<CefBrowser> m_browser;
    CefRefPtr<NetscapeClient> m_client;
    NetscapeMainWindow* m_mainWindow;
    bool m_browserCreated = false;
    QString m_pendingUrl;
};

#endif // CEF_BROWSER_WIDGET_H
