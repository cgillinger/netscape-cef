#include "NetscapeDisplayHandler.h"
#include "ui/NetscapeMainWindow.h"

#include <QMetaObject>

NetscapeDisplayHandler::NetscapeDisplayHandler(NetscapeMainWindow* window)
    : m_window(window) {
}

void NetscapeDisplayHandler::OnAddressChange(
    CefRefPtr<CefBrowser> browser,
    CefRefPtr<CefFrame> frame,
    const CefString& url) {

    if (!m_window || !frame->IsMain()) return;

    QString urlStr = QString::fromStdString(url.ToString());

    QMetaObject::invokeMethod(m_window, [=]() {
        m_window->setUrl(urlStr);

        // Update security indicator based on URL
        if (urlStr.startsWith("https://")) {
            m_window->setSecurityState(NetscapeMainWindow::SecurityState::Secure);
        } else {
            m_window->setSecurityState(NetscapeMainWindow::SecurityState::Insecure);
        }
    }, Qt::QueuedConnection);
}

void NetscapeDisplayHandler::OnTitleChange(
    CefRefPtr<CefBrowser> browser,
    const CefString& title) {

    if (!m_window) return;

    QString titleStr = QString::fromStdString(title.ToString());

    QMetaObject::invokeMethod(m_window, [=]() {
        QString windowTitle;
        if (titleStr.isEmpty()) {
            windowTitle = "Netscape";
        } else {
            windowTitle = titleStr + " - Netscape";
        }
        m_window->setWindowTitle(windowTitle);
    }, Qt::QueuedConnection);
}

void NetscapeDisplayHandler::OnStatusMessage(
    CefRefPtr<CefBrowser> browser,
    const CefString& value) {

    if (!m_window) return;

    QString status = QString::fromStdString(value.ToString());

    QMetaObject::invokeMethod(m_window, [=]() {
        if (status.isEmpty()) {
            m_window->setStatusText("Document: Done");
        } else {
            m_window->setStatusText(status);
        }
    }, Qt::QueuedConnection);
}

bool NetscapeDisplayHandler::OnConsoleMessage(
    CefRefPtr<CefBrowser> browser,
    cef_log_severity_t level,
    const CefString& message,
    const CefString& source,
    int line) {

    // Suppress console messages - classic Netscape didn't have a console
    return true;
}

void NetscapeDisplayHandler::OnFaviconURLChange(
    CefRefPtr<CefBrowser> browser,
    const std::vector<CefString>& icon_urls) {

    // Classic Netscape didn't show favicons, but we could add support
    // For now, ignore
}
