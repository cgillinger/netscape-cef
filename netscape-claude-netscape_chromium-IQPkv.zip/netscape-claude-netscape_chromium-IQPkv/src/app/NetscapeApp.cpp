#include "NetscapeApp.h"
#include "include/cef_browser.h"
#include "include/cef_command_line.h"

void NetscapeApp::OnBeforeCommandLineProcessing(
    const CefString& process_type,
    CefRefPtr<CefCommandLine> command_line) {

    // Disable features not needed for classic browser experience
    command_line->AppendSwitch("disable-extensions");
    command_line->AppendSwitch("disable-plugins-discovery");

    // Enable hardware acceleration
    command_line->AppendSwitch("enable-gpu");

    // Disable some modern UI elements
    command_line->AppendSwitch("disable-infobars");
}

void NetscapeApp::OnContextInitialized() {
    // Browser context is ready
    // Additional initialization can be done here
}
