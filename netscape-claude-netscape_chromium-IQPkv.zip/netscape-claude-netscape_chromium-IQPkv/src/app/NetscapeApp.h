#ifndef NETSCAPE_APP_H
#define NETSCAPE_APP_H

#include "include/cef_app.h"
#include "include/cef_browser_process_handler.h"

/**
 * CEF Application handler
 * Manages browser process initialization and configuration
 */
class NetscapeApp : public CefApp,
                    public CefBrowserProcessHandler {
public:
    NetscapeApp() = default;

    // CefApp methods
    CefRefPtr<CefBrowserProcessHandler> GetBrowserProcessHandler() override {
        return this;
    }

    void OnBeforeCommandLineProcessing(
        const CefString& process_type,
        CefRefPtr<CefCommandLine> command_line) override;

    // CefBrowserProcessHandler methods
    void OnContextInitialized() override;

private:
    IMPLEMENT_REFCOUNTING(NetscapeApp);
    DISALLOW_COPY_AND_ASSIGN(NetscapeApp);
};

#endif // NETSCAPE_APP_H
