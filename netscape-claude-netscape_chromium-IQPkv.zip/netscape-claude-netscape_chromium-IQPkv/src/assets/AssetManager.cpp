#include "AssetManager.h"

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QImage>
#include <QDebug>

AssetManager& AssetManager::instance() {
    static AssetManager instance;
    return instance;
}

void AssetManager::initialize(qreal devicePixelRatio) {
    // Determine scale mode based on DPI
    if (devicePixelRatio <= 1.0) {
        m_scaleMode = Scale1x;
    } else if (devicePixelRatio <= 1.5) {
        m_scaleMode = Scale1_5x;
    } else if (devicePixelRatio <= 2.0) {
        m_scaleMode = Scale2x;
    } else {
        m_scaleMode = Scale3x;
    }

    // Set asset base path
    m_assetBasePath = QCoreApplication::applicationDirPath() + "/assets";

    // Also check for assets in source directory during development
    if (!QDir(m_assetBasePath).exists()) {
        m_assetBasePath = ":/assets";  // Qt resource path
    }

    qDebug() << "AssetManager initialized with scale mode:" << m_scaleMode
             << "base path:" << m_assetBasePath;
}

QPixmap AssetManager::getPixmap(const QString& name) {
    // Check cache first
    QString cacheKey = QString("%1@%2").arg(name).arg(m_scaleMode);
    if (m_cache.contains(cacheKey)) {
        return m_cache[cacheKey];
    }

    // Try to load pre-scaled asset
    QString scaleSuffix;
    switch (m_scaleMode) {
    case Scale2x:
        scaleSuffix = "2x";
        break;
    case Scale3x:
        scaleSuffix = "3x";
        break;
    default:
        scaleSuffix = "1x";
        break;
    }

    QString path = QString("%1/%2/%3.png")
        .arg(m_assetBasePath, scaleSuffix, name);

    QPixmap pixmap;
    if (QFile::exists(path)) {
        pixmap.load(path);
    } else {
        // Fallback to 1x and scale
        path = QString("%1/1x/%2.png").arg(m_assetBasePath, name);
        if (QFile::exists(path)) {
            QPixmap original(path);
            pixmap = scalePixmap(original, m_scaleMode);
        } else {
            // Try Qt resource path
            path = QString(":/assets/1x/%1.png").arg(name);
            if (QFile::exists(path)) {
                QPixmap original(path);
                pixmap = scalePixmap(original, m_scaleMode);
            } else {
                qWarning() << "Asset not found:" << name;
            }
        }
    }

    // Cache and return
    if (!pixmap.isNull()) {
        m_cache[cacheKey] = pixmap;
    }

    return pixmap;
}

QPixmap AssetManager::getRawPixmap(const QString& path) {
    if (m_cache.contains(path)) {
        return m_cache[path];
    }

    QPixmap pixmap(path);
    if (!pixmap.isNull()) {
        m_cache[path] = pixmap;
    }

    return pixmap;
}

void AssetManager::clearCache() {
    m_cache.clear();
}

QString AssetManager::getAssetPath(const QString& name) {
    QString scaleSuffix;
    switch (m_scaleMode) {
    case Scale2x:
        scaleSuffix = "2x";
        break;
    case Scale3x:
        scaleSuffix = "3x";
        break;
    default:
        scaleSuffix = "1x";
        break;
    }

    return QString("%1/%2/%3.png").arg(m_assetBasePath, scaleSuffix, name);
}

QPixmap AssetManager::scalePixmap(const QPixmap& source, ScaleMode targetScale) {
    if (source.isNull()) return source;

    int scaleFactor;
    switch (targetScale) {
    case Scale2x:
        scaleFactor = 2;
        break;
    case Scale3x:
        scaleFactor = 3;
        break;
    case Scale1_5x:
        // For 1.5x, scale to 2x then down to 1.5x with smoothing
        {
            QImage img = source.toImage();
            // First scale up 2x with nearest neighbor
            QImage scaled2x = img.scaled(
                img.size() * 2,
                Qt::KeepAspectRatio,
                Qt::FastTransformation
            );
            // Then scale to 1.5x with smoothing
            QImage scaled1_5x = scaled2x.scaled(
                img.size() * 1.5,
                Qt::KeepAspectRatio,
                Qt::SmoothTransformation
            );
            return QPixmap::fromImage(scaled1_5x);
        }
    default:
        return source;
    }

    // Integer scaling with nearest neighbor for pixel-perfect enlargement
    QImage img = source.toImage();
    QImage scaled = img.scaled(
        img.size() * scaleFactor,
        Qt::KeepAspectRatio,
        Qt::FastTransformation  // Nearest neighbor
    );

    return QPixmap::fromImage(scaled);
}
