#ifndef ASSET_MANAGER_H
#define ASSET_MANAGER_H

#include <QHash>
#include <QPixmap>
#include <QString>

/**
 * Manages loading and caching of graphical assets
 * Handles DPI scaling for HiDPI displays
 */
class AssetManager {
public:
    enum ScaleMode {
        Scale1x,    // 96 DPI - Original assets
        Scale1_5x,  // 144 DPI - 150%
        Scale2x,    // 192 DPI - 200% (Retina/HiDPI)
        Scale3x     // 288 DPI - 300% (4K+)
    };

    // Singleton access
    static AssetManager& instance();

    // Initialize with device pixel ratio
    void initialize(qreal devicePixelRatio);

    // Get scaled pixmap by name (without extension)
    // Example: getPixmap("toolbar/TB_Back")
    QPixmap getPixmap(const QString& name);

    // Get raw pixmap without scaling
    QPixmap getRawPixmap(const QString& path);

    // Clear cache
    void clearCache();

    // Current scale mode
    ScaleMode scaleMode() const { return m_scaleMode; }

private:
    AssetManager() = default;
    ~AssetManager() = default;
    AssetManager(const AssetManager&) = delete;
    AssetManager& operator=(const AssetManager&) = delete;

    QString getAssetPath(const QString& name);
    QPixmap scalePixmap(const QPixmap& source, ScaleMode targetScale);

    QHash<QString, QPixmap> m_cache;
    ScaleMode m_scaleMode = Scale1x;
    QString m_assetBasePath;
};

#endif // ASSET_MANAGER_H
