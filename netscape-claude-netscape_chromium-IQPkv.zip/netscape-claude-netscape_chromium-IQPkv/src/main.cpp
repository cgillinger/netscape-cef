/**
 * Netscape Navigator CEF Browser
 * Main entry point
 *
 * Recreates the classic Netscape Navigator 4.x UI using:
 * - Qt6 for native desktop UI
 * - CEF (Chromium Embedded Framework) for web rendering
 */

#include <QApplication>
#include <QScreen>

#include "include/cef_app.h"
#include "include/cef_browser.h"
#include "include/cef_command_line.h"

#include "app/NetscapeApp.h"
#include "ui/NetscapeMainWindow.h"
#include "assets/AssetManager.h"

#ifdef Q_OS_LINUX
#include <X11/Xlib.h>
#endif

int main(int argc, char* argv[]) {
#ifdef Q_OS_LINUX
    // Required for CEF on Linux
    XInitThreads();
#endif

    // CEF initialization - must be before QApplication
    CefMainArgs mainArgs(argc, argv);
    CefRefPtr<NetscapeApp> cefApp(new NetscapeApp);

    // Check if this is a CEF sub-process
    int exitCode = CefExecuteProcess(mainArgs, cefApp, nullptr);
    if (exitCode >= 0) {
        // Sub-process has completed
        return exitCode;
    }

    // CEF settings
    CefSettings settings;
    settings.multi_threaded_message_loop = true;
    settings.windowless_rendering_enabled = false;

#ifdef NDEBUG
    settings.log_severity = LOGSEVERITY_WARNING;
#else
    settings.log_severity = LOGSEVERITY_INFO;
#endif

    // Set cache path
    CefString(&settings.cache_path).FromASCII("/tmp/netscape-cef-cache");

    // User agent string (classic Netscape style with modern engine info)
    CefString(&settings.user_agent).FromASCII(
        "Mozilla/5.0 (X11; Linux x86_64) Netscape/4.8 (CEF/Chromium)"
    );

    // Initialize CEF
    if (!CefInitialize(mainArgs, settings, cefApp, nullptr)) {
        return 1;
    }

    // Qt initialization
    QApplication app(argc, argv);
    app.setApplicationName("Netscape");
    app.setApplicationVersion("4.8-CEF");
    app.setOrganizationName("Netscape Communications");

    // Initialize asset manager with current DPI
    QScreen* screen = QApplication::primaryScreen();
    AssetManager::instance().initialize(screen->devicePixelRatio());

    // Create and show main window
    NetscapeMainWindow mainWindow;
    mainWindow.setWindowTitle("Netscape");
    mainWindow.resize(800, 600);
    mainWindow.show();

    // Navigate to home page
    mainWindow.navigateTo("https://www.google.com");

    // Run Qt event loop
    int result = app.exec();

    // Shutdown CEF
    CefShutdown();

    return result;
}
