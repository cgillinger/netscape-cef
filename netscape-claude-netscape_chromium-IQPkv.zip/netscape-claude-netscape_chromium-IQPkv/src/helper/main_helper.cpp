/**
 * CEF Helper Process
 * Separate process for renderer, GPU, etc.
 */

#include "include/cef_app.h"

#ifdef Q_OS_LINUX
#include <X11/Xlib.h>
#endif

int main(int argc, char* argv[]) {
#ifdef Q_OS_LINUX
    XInitThreads();
#endif

    CefMainArgs mainArgs(argc, argv);

    // Execute sub-process
    return CefExecuteProcess(mainArgs, nullptr, nullptr);
}
