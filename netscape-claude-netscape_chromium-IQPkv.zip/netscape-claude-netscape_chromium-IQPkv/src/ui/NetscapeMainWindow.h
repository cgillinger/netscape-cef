#ifndef NETSCAPE_MAIN_WINDOW_H
#define NETSCAPE_MAIN_WINDOW_H

#include <QMainWindow>
#include <QPointer>

class NavigationToolbar;
class LocationToolbar;
class NetscapeStatusBar;
class NetscapeMenuBar;
class CefBrowserWidget;
class ThrobberWidget;

/**
 * Main application window
 * Recreates classic Netscape Navigator 4.x appearance
 */
class NetscapeMainWindow : public QMainWindow {
    Q_OBJECT

public:
    enum class SecurityState {
        Insecure,    // HTTP
        Secure,      // HTTPS valid
        MixedContent,// HTTPS with HTTP resources
        CertError    // Certificate problem
    };

    explicit NetscapeMainWindow(QWidget* parent = nullptr);
    ~NetscapeMainWindow() override;

    // Navigation
    void navigateTo(const QString& url);

    // UI updates from CEF handlers
    void setUrl(const QString& url);
    void setStatusText(const QString& text);
    void setProgress(int percent);
    void showProgress(bool show);
    void setSecurityState(SecurityState state);

    // Navigation button states
    void setBackEnabled(bool enabled);
    void setForwardEnabled(bool enabled);
    void setStopVisible(bool visible);
    void setReloadVisible(bool visible);

    // Throbber control
    void startThrobber();
    void stopThrobber();

public slots:
    // Navigation actions
    void onBack();
    void onForward();
    void onReload();
    void onStop();
    void onHome();
    void onSearch();
    void onPrint();

    // Location bar
    void onUrlEntered(const QString& url);

protected:
    void closeEvent(QCloseEvent* event) override;

private:
    void setupUi();
    void setupMenuBar();
    void setupToolbars();
    void setupStatusBar();
    void connectSignals();

    // UI components
    NetscapeMenuBar* m_menuBar;
    NavigationToolbar* m_navToolbar;
    LocationToolbar* m_locationToolbar;
    CefBrowserWidget* m_browserWidget;
    NetscapeStatusBar* m_statusBar;

    // Home page URL
    QString m_homeUrl = "https://www.google.com";
};

#endif // NETSCAPE_MAIN_WINDOW_H
