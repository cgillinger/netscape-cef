#include "LocationToolbar.h"

#include <QHBoxLayout>
#include <QLabel>
#include <QComboBox>
#include <QLineEdit>
#include <QPainter>
#include <QKeyEvent>

LocationToolbar::LocationToolbar(QWidget* parent)
    : QWidget(parent) {

    setFixedHeight(28);

    QHBoxLayout* layout = new QHBoxLayout(this);
    layout->setContentsMargins(6, 2, 6, 2);
    layout->setSpacing(6);

    // "Location:" label
    m_locationLabel = new QLabel("Location:", this);
    m_locationLabel->setStyleSheet(
        "QLabel {"
        "  color: black;"
        "  font-weight: bold;"
        "  font-size: 11px;"
        "}"
    );
    layout->addWidget(m_locationLabel);

    // URL combo box (editable)
    m_urlCombo = new QComboBox(this);
    m_urlCombo->setEditable(true);
    m_urlCombo->setInsertPolicy(QComboBox::InsertAtTop);
    m_urlCombo->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    m_urlCombo->setMaxCount(20);  // Keep last 20 URLs

    // Classic styling
    m_urlCombo->setStyleSheet(
        "QComboBox {"
        "  background-color: white;"
        "  border: 2px inset #808080;"
        "  padding: 2px 4px;"
        "  font-family: 'Courier New', monospace;"
        "  font-size: 11px;"
        "}"
        "QComboBox::drop-down {"
        "  border: none;"
        "  width: 16px;"
        "}"
        "QComboBox::down-arrow {"
        "  width: 8px;"
        "  height: 8px;"
        "}"
        "QComboBox QAbstractItemView {"
        "  background-color: white;"
        "  selection-background-color: #000080;"
        "  selection-color: white;"
        "}"
    );

    layout->addWidget(m_urlCombo);

    // Connect enter key
    connect(m_urlCombo->lineEdit(), &QLineEdit::returnPressed,
            this, &LocationToolbar::onReturnPressed);
}

void LocationToolbar::setUrl(const QString& url) {
    // Don't trigger signals when setting programmatically
    m_urlCombo->blockSignals(true);
    m_urlCombo->setCurrentText(url);
    m_urlCombo->blockSignals(false);

    // Add to history if not already present
    int index = m_urlCombo->findText(url);
    if (index == -1) {
        m_urlCombo->insertItem(0, url);
    }
}

QString LocationToolbar::url() const {
    return m_urlCombo->currentText();
}

void LocationToolbar::onReturnPressed() {
    QString url = m_urlCombo->currentText().trimmed();
    if (!url.isEmpty()) {
        emit urlEntered(url);
    }
}

void LocationToolbar::paintEvent(QPaintEvent* event) {
    QPainter painter(this);

    // Classic toolbar gray background
    painter.fillRect(rect(), QColor(192, 192, 192));

    // Top highlight
    painter.setPen(QColor(255, 255, 255));
    painter.drawLine(0, 0, width(), 0);

    // Bottom shadow
    painter.setPen(QColor(128, 128, 128));
    painter.drawLine(0, height() - 1, width(), height() - 1);

    QWidget::paintEvent(event);
}
