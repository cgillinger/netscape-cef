#ifndef NETSCAPE_MENU_BAR_H
#define NETSCAPE_MENU_BAR_H

#include <QMenuBar>

class NetscapeMainWindow;

/**
 * Classic Netscape menu bar
 * File, Edit, View, Go, Communicator, Help
 */
class NetscapeMenuBar : public QMenuBar {
    Q_OBJECT

public:
    explicit NetscapeMenuBar(NetscapeMainWindow* parent);

private:
    void setupFileMenu();
    void setupEditMenu();
    void setupViewMenu();
    void setupGoMenu();
    void setupCommunicatorMenu();
    void setupHelpMenu();

    NetscapeMainWindow* m_mainWindow;

    QMenu* m_fileMenu;
    QMenu* m_editMenu;
    QMenu* m_viewMenu;
    QMenu* m_goMenu;
    QMenu* m_communicatorMenu;
    QMenu* m_helpMenu;
};

#endif // NETSCAPE_MENU_BAR_H
