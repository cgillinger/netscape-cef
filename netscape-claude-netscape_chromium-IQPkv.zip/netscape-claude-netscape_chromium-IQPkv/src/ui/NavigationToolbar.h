#ifndef NAVIGATION_TOOLBAR_H
#define NAVIGATION_TOOLBAR_H

#include <QWidget>
#include "NetscapeMainWindow.h"

class NetscapeButton;
class ThrobberWidget;

/**
 * Navigation toolbar with classic Netscape buttons
 * Back, Forward, Reload, Stop, Home, Search, Print, Security + Throbber
 */
class NavigationToolbar : public QWidget {
    Q_OBJECT

public:
    explicit NavigationToolbar(QWidget* parent = nullptr);

    // Button states
    void setBackEnabled(bool enabled);
    void setForwardEnabled(bool enabled);
    void setStopVisible(bool visible);
    void setReloadVisible(bool visible);
    void setSecurityState(NetscapeMainWindow::SecurityState state);

    // Throbber control
    void startThrobber();
    void stopThrobber();

signals:
    void backClicked();
    void forwardClicked();
    void reloadClicked();
    void stopClicked();
    void homeClicked();
    void searchClicked();
    void printClicked();
    void securityClicked();

protected:
    void paintEvent(QPaintEvent* event) override;

private:
    void setupButtons();

    NetscapeButton* m_backBtn;
    NetscapeButton* m_forwardBtn;
    NetscapeButton* m_reloadBtn;
    NetscapeButton* m_stopBtn;
    NetscapeButton* m_homeBtn;
    NetscapeButton* m_searchBtn;
    NetscapeButton* m_printBtn;
    NetscapeButton* m_securityBtn;
    ThrobberWidget* m_throbber;
};

#endif // NAVIGATION_TOOLBAR_H
