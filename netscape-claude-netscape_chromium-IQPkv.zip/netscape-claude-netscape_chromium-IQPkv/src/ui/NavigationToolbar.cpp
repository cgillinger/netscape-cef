#include "NavigationToolbar.h"
#include "widgets/NetscapeButton.h"
#include "widgets/ThrobberWidget.h"
#include "assets/AssetManager.h"

#include <QHBoxLayout>
#include <QPainter>

NavigationToolbar::NavigationToolbar(QWidget* parent)
    : QWidget(parent) {

    setFixedHeight(50);
    setupButtons();
}

void NavigationToolbar::setupButtons() {
    QHBoxLayout* layout = new QHBoxLayout(this);
    layout->setContentsMargins(4, 4, 4, 4);
    layout->setSpacing(2);

    AssetManager& assets = AssetManager::instance();

    // Back button
    m_backBtn = new NetscapeButton(this);
    m_backBtn->setAssets(
        assets.getPixmap("toolbar/TB_Back"),
        assets.getPixmap("toolbar/TB_Back.mo"),
        assets.getPixmap("toolbar/TB_Back.md"),
        assets.getPixmap("toolbar/TB_Back.i")
    );
    m_backBtn->setToolTip("Back");
    m_backBtn->setEnabled(false);
    connect(m_backBtn, &NetscapeButton::clicked, this, &NavigationToolbar::backClicked);
    layout->addWidget(m_backBtn);

    // Forward button
    m_forwardBtn = new NetscapeButton(this);
    m_forwardBtn->setAssets(
        assets.getPixmap("toolbar/TB_Forward"),
        assets.getPixmap("toolbar/TB_Forward.mo"),
        assets.getPixmap("toolbar/TB_Forward.md"),
        assets.getPixmap("toolbar/TB_Forward.i")
    );
    m_forwardBtn->setToolTip("Forward");
    m_forwardBtn->setEnabled(false);
    connect(m_forwardBtn, &NetscapeButton::clicked, this, &NavigationToolbar::forwardClicked);
    layout->addWidget(m_forwardBtn);

    // Reload button
    m_reloadBtn = new NetscapeButton(this);
    m_reloadBtn->setAssets(
        assets.getPixmap("toolbar/TB_Reload"),
        assets.getPixmap("toolbar/TB_Reload.mo"),
        assets.getPixmap("toolbar/TB_Reload.md"),
        assets.getPixmap("toolbar/TB_Reload.i")
    );
    m_reloadBtn->setToolTip("Reload");
    connect(m_reloadBtn, &NetscapeButton::clicked, this, &NavigationToolbar::reloadClicked);
    layout->addWidget(m_reloadBtn);

    // Stop button (overlaps with Reload)
    m_stopBtn = new NetscapeButton(this);
    m_stopBtn->setAssets(
        assets.getPixmap("toolbar/TB_Stop"),
        assets.getPixmap("toolbar/TB_Stop.mo"),
        assets.getPixmap("toolbar/TB_Stop.md"),
        assets.getPixmap("toolbar/TB_Stop.i")
    );
    m_stopBtn->setToolTip("Stop");
    m_stopBtn->setVisible(false);
    connect(m_stopBtn, &NetscapeButton::clicked, this, &NavigationToolbar::stopClicked);
    layout->addWidget(m_stopBtn);

    // Home button
    m_homeBtn = new NetscapeButton(this);
    m_homeBtn->setAssets(
        assets.getPixmap("toolbar/TB_Home"),
        assets.getPixmap("toolbar/TB_Home.mo"),
        assets.getPixmap("toolbar/TB_Home.md"),
        assets.getPixmap("toolbar/TB_Home.i")
    );
    m_homeBtn->setToolTip("Home");
    connect(m_homeBtn, &NetscapeButton::clicked, this, &NavigationToolbar::homeClicked);
    layout->addWidget(m_homeBtn);

    // Search button
    m_searchBtn = new NetscapeButton(this);
    m_searchBtn->setAssets(
        assets.getPixmap("toolbar/TB_Search"),
        assets.getPixmap("toolbar/TB_Search.mo"),
        assets.getPixmap("toolbar/TB_Search.md"),
        assets.getPixmap("toolbar/TB_Search.i")
    );
    m_searchBtn->setToolTip("Search");
    connect(m_searchBtn, &NetscapeButton::clicked, this, &NavigationToolbar::searchClicked);
    layout->addWidget(m_searchBtn);

    // Print button
    m_printBtn = new NetscapeButton(this);
    m_printBtn->setAssets(
        assets.getPixmap("toolbar/TB_Print"),
        assets.getPixmap("toolbar/TB_Print.mo"),
        assets.getPixmap("toolbar/TB_Print.md"),
        assets.getPixmap("toolbar/TB_Print.i")
    );
    m_printBtn->setToolTip("Print");
    connect(m_printBtn, &NetscapeButton::clicked, this, &NavigationToolbar::printClicked);
    layout->addWidget(m_printBtn);

    // Security button
    m_securityBtn = new NetscapeButton(this);
    m_securityBtn->setAssets(
        assets.getPixmap("toolbar/TB_Unsecure"),
        assets.getPixmap("toolbar/TB_Unsecure"),
        assets.getPixmap("toolbar/TB_Unsecure"),
        assets.getPixmap("toolbar/TB_Unsecure")
    );
    m_securityBtn->setToolTip("Security");
    connect(m_securityBtn, &NetscapeButton::clicked, this, &NavigationToolbar::securityClicked);
    layout->addWidget(m_securityBtn);

    // Spacer
    layout->addStretch();

    // Throbber (N logo animation)
    m_throbber = new ThrobberWidget(this);
    layout->addWidget(m_throbber);
}

void NavigationToolbar::setBackEnabled(bool enabled) {
    m_backBtn->setEnabled(enabled);
}

void NavigationToolbar::setForwardEnabled(bool enabled) {
    m_forwardBtn->setEnabled(enabled);
}

void NavigationToolbar::setStopVisible(bool visible) {
    m_stopBtn->setVisible(visible);
    m_reloadBtn->setVisible(!visible);
}

void NavigationToolbar::setReloadVisible(bool visible) {
    m_reloadBtn->setVisible(visible);
    m_stopBtn->setVisible(!visible);
}

void NavigationToolbar::setSecurityState(NetscapeMainWindow::SecurityState state) {
    AssetManager& assets = AssetManager::instance();

    switch (state) {
    case NetscapeMainWindow::SecurityState::Secure:
        m_securityBtn->setAssets(
            assets.getPixmap("toolbar/TB_Secure"),
            assets.getPixmap("toolbar/TB_Secure.mo"),
            assets.getPixmap("toolbar/TB_Secure.md"),
            assets.getPixmap("toolbar/TB_Secure")
        );
        m_securityBtn->setToolTip("Secure Connection");
        break;

    case NetscapeMainWindow::SecurityState::MixedContent:
        m_securityBtn->setAssets(
            assets.getPixmap("toolbar/TB_MixSecurity"),
            assets.getPixmap("toolbar/TB_MixSecurity"),
            assets.getPixmap("toolbar/TB_MixSecurity"),
            assets.getPixmap("toolbar/TB_MixSecurity")
        );
        m_securityBtn->setToolTip("Mixed Security");
        break;

    case NetscapeMainWindow::SecurityState::CertError:
    case NetscapeMainWindow::SecurityState::Insecure:
    default:
        m_securityBtn->setAssets(
            assets.getPixmap("toolbar/TB_Unsecure"),
            assets.getPixmap("toolbar/TB_Unsecure"),
            assets.getPixmap("toolbar/TB_Unsecure"),
            assets.getPixmap("toolbar/TB_Unsecure")
        );
        m_securityBtn->setToolTip("Insecure Connection");
        break;
    }

    m_securityBtn->update();
}

void NavigationToolbar::startThrobber() {
    m_throbber->startAnimation();
}

void NavigationToolbar::stopThrobber() {
    m_throbber->stopAnimation();
}

void NavigationToolbar::paintEvent(QPaintEvent* event) {
    QPainter painter(this);

    // Classic toolbar gray background
    painter.fillRect(rect(), QColor(192, 192, 192));

    // Top highlight
    painter.setPen(QColor(255, 255, 255));
    painter.drawLine(0, 0, width(), 0);

    // Bottom shadow
    painter.setPen(QColor(128, 128, 128));
    painter.drawLine(0, height() - 1, width(), height() - 1);

    QWidget::paintEvent(event);
}
