#ifndef NETSCAPE_STATUS_BAR_H
#define NETSCAPE_STATUS_BAR_H

#include <QStatusBar>
#include "NetscapeMainWindow.h"

class QLabel;
class QProgressBar;

/**
 * Classic Netscape-style status bar
 * Security indicator, status text, progress bar
 */
class NetscapeStatusBar : public QStatusBar {
    Q_OBJECT

public:
    explicit NetscapeStatusBar(QWidget* parent = nullptr);

    void setText(const QString& text);
    void setProgress(int percent);
    void showProgress(bool show);
    void setSecurityState(NetscapeMainWindow::SecurityState state);

protected:
    void paintEvent(QPaintEvent* event) override;

private:
    QLabel* m_securityIcon;
    QLabel* m_statusText;
    QProgressBar* m_progressBar;
};

#endif // NETSCAPE_STATUS_BAR_H
