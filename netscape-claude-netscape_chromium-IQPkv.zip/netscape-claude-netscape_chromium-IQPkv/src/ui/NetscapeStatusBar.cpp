#include "NetscapeStatusBar.h"
#include "assets/AssetManager.h"

#include <QLabel>
#include <QProgressBar>
#include <QHBoxLayout>
#include <QPainter>

NetscapeStatusBar::NetscapeStatusBar(QWidget* parent)
    : QStatusBar(parent) {

    setFixedHeight(24);
    setSizeGripEnabled(true);

    // Security icon
    m_securityIcon = new QLabel(this);
    m_securityIcon->setFixedSize(18, 18);
    m_securityIcon->setScaledContents(true);
    addWidget(m_securityIcon);

    // Status text
    m_statusText = new QLabel("Document: Done", this);
    m_statusText->setStyleSheet(
        "QLabel {"
        "  color: black;"
        "  font-size: 11px;"
        "  padding-left: 4px;"
        "}"
    );
    addWidget(m_statusText, 1);

    // Progress bar (hidden by default)
    m_progressBar = new QProgressBar(this);
    m_progressBar->setFixedWidth(150);
    m_progressBar->setFixedHeight(16);
    m_progressBar->setTextVisible(false);
    m_progressBar->setRange(0, 100);
    m_progressBar->setVisible(false);
    m_progressBar->setStyleSheet(
        "QProgressBar {"
        "  border: 2px inset #808080;"
        "  background-color: #c0c0c0;"
        "}"
        "QProgressBar::chunk {"
        "  background-color: #000080;"
        "}"
    );
    addPermanentWidget(m_progressBar);

    // Set default insecure state
    setSecurityState(NetscapeMainWindow::SecurityState::Insecure);

    // Styling
    setStyleSheet(
        "QStatusBar {"
        "  background-color: #c0c0c0;"
        "  border-top: 1px solid #808080;"
        "}"
        "QStatusBar::item {"
        "  border: none;"
        "}"
    );
}

void NetscapeStatusBar::setText(const QString& text) {
    m_statusText->setText(text);
}

void NetscapeStatusBar::setProgress(int percent) {
    m_progressBar->setValue(percent);
}

void NetscapeStatusBar::showProgress(bool show) {
    m_progressBar->setVisible(show);
    if (show) {
        m_progressBar->setValue(0);
    }
}

void NetscapeStatusBar::setSecurityState(NetscapeMainWindow::SecurityState state) {
    AssetManager& assets = AssetManager::instance();
    QPixmap icon;

    switch (state) {
    case NetscapeMainWindow::SecurityState::Secure:
        icon = assets.getPixmap("icons/Dash_Secure");
        break;
    case NetscapeMainWindow::SecurityState::MixedContent:
        icon = assets.getPixmap("icons/Dash_MixSecurity");
        break;
    case NetscapeMainWindow::SecurityState::CertError:
    case NetscapeMainWindow::SecurityState::Insecure:
    default:
        icon = assets.getPixmap("icons/Dash_Unsecure");
        break;
    }

    if (!icon.isNull()) {
        m_securityIcon->setPixmap(icon.scaled(16, 16, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    }
}

void NetscapeStatusBar::paintEvent(QPaintEvent* event) {
    QPainter painter(this);

    // Background
    painter.fillRect(rect(), QColor(192, 192, 192));

    // Top border (inset effect)
    painter.setPen(QColor(128, 128, 128));
    painter.drawLine(0, 0, width(), 0);

    painter.setPen(QColor(255, 255, 255));
    painter.drawLine(0, 1, width(), 1);

    QStatusBar::paintEvent(event);
}
