#include "NetscapeMainWindow.h"
#include "NavigationToolbar.h"
#include "LocationToolbar.h"
#include "NetscapeStatusBar.h"
#include "NetscapeMenuBar.h"
#include "browser/CefBrowserWidget.h"

#include <QVBoxLayout>
#include <QCloseEvent>
#include <QDesktopServices>
#include <QUrl>

NetscapeMainWindow::NetscapeMainWindow(QWidget* parent)
    : QMainWindow(parent) {

    setupUi();
    connectSignals();

    // Classic Netscape gray background
    setStyleSheet("QMainWindow { background-color: #c0c0c0; }");
}

NetscapeMainWindow::~NetscapeMainWindow() = default;

void NetscapeMainWindow::setupUi() {
    // Central widget with layout
    QWidget* centralWidget = new QWidget(this);
    QVBoxLayout* layout = new QVBoxLayout(centralWidget);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(0);

    // Menu bar
    setupMenuBar();

    // Navigation toolbar
    m_navToolbar = new NavigationToolbar(this);
    layout->addWidget(m_navToolbar);

    // Location toolbar
    m_locationToolbar = new LocationToolbar(this);
    layout->addWidget(m_locationToolbar);

    // Browser view (CEF)
    m_browserWidget = new CefBrowserWidget(this, this);
    m_browserWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    layout->addWidget(m_browserWidget, 1);

    setCentralWidget(centralWidget);

    // Status bar
    setupStatusBar();

    // Window size
    resize(800, 600);
}

void NetscapeMainWindow::setupMenuBar() {
    m_menuBar = new NetscapeMenuBar(this);
    setMenuBar(m_menuBar);
}

void NetscapeMainWindow::setupToolbars() {
    // Already done in setupUi
}

void NetscapeMainWindow::setupStatusBar() {
    m_statusBar = new NetscapeStatusBar(this);
    setStatusBar(m_statusBar);
}

void NetscapeMainWindow::connectSignals() {
    // Navigation toolbar signals
    connect(m_navToolbar, &NavigationToolbar::backClicked, this, &NetscapeMainWindow::onBack);
    connect(m_navToolbar, &NavigationToolbar::forwardClicked, this, &NetscapeMainWindow::onForward);
    connect(m_navToolbar, &NavigationToolbar::reloadClicked, this, &NetscapeMainWindow::onReload);
    connect(m_navToolbar, &NavigationToolbar::stopClicked, this, &NetscapeMainWindow::onStop);
    connect(m_navToolbar, &NavigationToolbar::homeClicked, this, &NetscapeMainWindow::onHome);
    connect(m_navToolbar, &NavigationToolbar::searchClicked, this, &NetscapeMainWindow::onSearch);
    connect(m_navToolbar, &NavigationToolbar::printClicked, this, &NetscapeMainWindow::onPrint);

    // Location bar signals
    connect(m_locationToolbar, &LocationToolbar::urlEntered, this, &NetscapeMainWindow::onUrlEntered);
}

void NetscapeMainWindow::navigateTo(const QString& url) {
    QString finalUrl = url;

    // Add http:// if no protocol specified
    if (!url.contains("://")) {
        finalUrl = "https://" + url;
    }

    m_browserWidget->createBrowser(finalUrl);
}

void NetscapeMainWindow::setUrl(const QString& url) {
    m_locationToolbar->setUrl(url);
}

void NetscapeMainWindow::setStatusText(const QString& text) {
    m_statusBar->setText(text);
}

void NetscapeMainWindow::setProgress(int percent) {
    m_statusBar->setProgress(percent);
}

void NetscapeMainWindow::showProgress(bool show) {
    m_statusBar->showProgress(show);
}

void NetscapeMainWindow::setSecurityState(SecurityState state) {
    m_navToolbar->setSecurityState(state);
    m_statusBar->setSecurityState(state);
}

void NetscapeMainWindow::setBackEnabled(bool enabled) {
    m_navToolbar->setBackEnabled(enabled);
}

void NetscapeMainWindow::setForwardEnabled(bool enabled) {
    m_navToolbar->setForwardEnabled(enabled);
}

void NetscapeMainWindow::setStopVisible(bool visible) {
    m_navToolbar->setStopVisible(visible);
}

void NetscapeMainWindow::setReloadVisible(bool visible) {
    m_navToolbar->setReloadVisible(visible);
}

void NetscapeMainWindow::startThrobber() {
    m_navToolbar->startThrobber();
}

void NetscapeMainWindow::stopThrobber() {
    m_navToolbar->stopThrobber();
}

void NetscapeMainWindow::onBack() {
    m_browserWidget->goBack();
}

void NetscapeMainWindow::onForward() {
    m_browserWidget->goForward();
}

void NetscapeMainWindow::onReload() {
    m_browserWidget->reload();
}

void NetscapeMainWindow::onStop() {
    m_browserWidget->stopLoad();
}

void NetscapeMainWindow::onHome() {
    navigateTo(m_homeUrl);
}

void NetscapeMainWindow::onSearch() {
    navigateTo("https://www.google.com");
}

void NetscapeMainWindow::onPrint() {
    // CEF print functionality would go here
    // For now, just show a message
    setStatusText("Print functionality not implemented");
}

void NetscapeMainWindow::onUrlEntered(const QString& url) {
    navigateTo(url);
}

void NetscapeMainWindow::closeEvent(QCloseEvent* event) {
    m_browserWidget->closeBrowser();
    event->accept();
}
