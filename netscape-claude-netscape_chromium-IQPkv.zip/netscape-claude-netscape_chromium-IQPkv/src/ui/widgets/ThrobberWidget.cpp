#include "ThrobberWidget.h"
#include "assets/AssetManager.h"

#include <QPainter>
#include <QTimer>

ThrobberWidget::ThrobberWidget(QWidget* parent)
    : QWidget(parent)
    , m_timer(new QTimer(this)) {

    setFixedSize(THROBBER_SIZE, THROBBER_SIZE);

    connect(m_timer, &QTimer::timeout, this, &ThrobberWidget::nextFrame);

    loadFrames();
}

ThrobberWidget::~ThrobberWidget() {
    stopAnimation();
}

void ThrobberWidget::loadFrames() {
    AssetManager& assets = AssetManager::instance();

    m_frames.clear();
    m_frames.reserve(FRAME_COUNT);

    for (int i = 0; i < FRAME_COUNT; ++i) {
        QString frameName = QString("throbber/AnimHuge%1")
            .arg(i, 2, 10, QChar('0'));
        QPixmap frame = assets.getPixmap(frameName);
        m_frames.append(frame);
    }

    // If frames didn't load, create placeholder
    if (m_frames.isEmpty() || m_frames[0].isNull()) {
        QPixmap placeholder(THROBBER_SIZE, THROBBER_SIZE);
        placeholder.fill(QColor(192, 192, 192));

        QPainter painter(&placeholder);
        painter.setPen(QColor(0, 0, 128));
        painter.setFont(QFont("Arial", 20, QFont::Bold));
        painter.drawText(placeholder.rect(), Qt::AlignCenter, "N");

        m_frames.clear();
        for (int i = 0; i < FRAME_COUNT; ++i) {
            m_frames.append(placeholder);
        }
    }
}

void ThrobberWidget::startAnimation() {
    if (m_animating) return;

    m_animating = true;
    m_currentFrame = 0;
    m_timer->start(FRAME_INTERVAL);
    update();
}

void ThrobberWidget::stopAnimation() {
    if (!m_animating) return;

    m_animating = false;
    m_timer->stop();
    m_currentFrame = 0;  // Return to first frame (static logo)
    update();
}

void ThrobberWidget::nextFrame() {
    m_currentFrame = (m_currentFrame + 1) % FRAME_COUNT;
    update();
}

QSize ThrobberWidget::sizeHint() const {
    return QSize(THROBBER_SIZE, THROBBER_SIZE);
}

QSize ThrobberWidget::minimumSizeHint() const {
    return QSize(THROBBER_SIZE, THROBBER_SIZE);
}

void ThrobberWidget::paintEvent(QPaintEvent* event) {
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::SmoothPixmapTransform);

    // Background
    painter.fillRect(rect(), QColor(192, 192, 192));

    // Draw current frame
    if (m_currentFrame < m_frames.size() && !m_frames[m_currentFrame].isNull()) {
        QPixmap scaled = m_frames[m_currentFrame].scaled(
            size(), Qt::KeepAspectRatio, Qt::SmoothTransformation);

        QRect iconRect = scaled.rect();
        iconRect.moveCenter(rect().center());
        painter.drawPixmap(iconRect, scaled);
    }
}
