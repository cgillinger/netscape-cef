#include "NetscapeStyle.h"

#include <QPainter>
#include <QStyleOption>

NetscapeStyle::NetscapeStyle()
    : QProxyStyle("Fusion") {
}

void NetscapeStyle::drawPrimitive(PrimitiveElement element,
                                   const QStyleOption* option,
                                   QPainter* painter,
                                   const QWidget* widget) const {

    switch (element) {
    case PE_Frame:
    case PE_FrameDefaultButton:
    case PE_FrameButtonBevel:
    case PE_FrameButtonTool: {
        // Classic 3D frame
        QRect r = option->rect;
        bool raised = !(option->state & State_Sunken);

        QColor light = raised ? highlightLight() : highlightDark();
        QColor dark = raised ? highlightDark() : highlightLight();

        painter->setPen(light);
        painter->drawLine(r.left(), r.top(), r.right() - 1, r.top());
        painter->drawLine(r.left(), r.top(), r.left(), r.bottom() - 1);

        painter->setPen(borderDark());
        painter->drawLine(r.right(), r.top(), r.right(), r.bottom());
        painter->drawLine(r.left(), r.bottom(), r.right(), r.bottom());

        painter->setPen(dark);
        painter->drawLine(r.right() - 1, r.top() + 1, r.right() - 1, r.bottom() - 1);
        painter->drawLine(r.left() + 1, r.bottom() - 1, r.right() - 1, r.bottom() - 1);

        return;
    }

    case PE_PanelButtonCommand: {
        // Button panel
        QRect r = option->rect;
        bool raised = !(option->state & State_Sunken);

        painter->fillRect(r.adjusted(2, 2, -2, -2), backgroundColor());

        QColor light = raised ? highlightLight() : highlightDark();
        QColor dark = raised ? highlightDark() : highlightLight();

        painter->setPen(light);
        painter->drawLine(r.left(), r.top(), r.right() - 1, r.top());
        painter->drawLine(r.left(), r.top(), r.left(), r.bottom() - 1);

        painter->setPen(borderDark());
        painter->drawLine(r.right(), r.top(), r.right(), r.bottom());
        painter->drawLine(r.left(), r.bottom(), r.right(), r.bottom());

        painter->setPen(dark);
        painter->drawLine(r.right() - 1, r.top() + 1, r.right() - 1, r.bottom() - 1);
        painter->drawLine(r.left() + 1, r.bottom() - 1, r.right() - 1, r.bottom() - 1);

        return;
    }

    default:
        break;
    }

    QProxyStyle::drawPrimitive(element, option, painter, widget);
}

void NetscapeStyle::drawControl(ControlElement element,
                                 const QStyleOption* option,
                                 QPainter* painter,
                                 const QWidget* widget) const {

    switch (element) {
    case CE_ProgressBarGroove: {
        // Sunken progress bar background
        QRect r = option->rect;

        painter->fillRect(r, backgroundColor());

        painter->setPen(highlightDark());
        painter->drawLine(r.left(), r.top(), r.right(), r.top());
        painter->drawLine(r.left(), r.top(), r.left(), r.bottom());

        painter->setPen(highlightLight());
        painter->drawLine(r.right(), r.top(), r.right(), r.bottom());
        painter->drawLine(r.left(), r.bottom(), r.right(), r.bottom());

        return;
    }

    case CE_ProgressBarContents: {
        // Blue progress chunks
        if (const QStyleOptionProgressBar* pb =
                qstyleoption_cast<const QStyleOptionProgressBar*>(option)) {

            if (pb->progress > 0) {
                QRect r = option->rect.adjusted(2, 2, -2, -2);
                int width = r.width() * pb->progress / pb->maximum;
                painter->fillRect(r.left(), r.top(), width, r.height(), selectionColor());
            }
        }
        return;
    }

    default:
        break;
    }

    QProxyStyle::drawControl(element, option, painter, widget);
}
