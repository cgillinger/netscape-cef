#ifndef THROBBER_WIDGET_H
#define THROBBER_WIDGET_H

#include <QWidget>
#include <QVector>
#include <QPixmap>

class QTimer;

/**
 * Classic Netscape "N" throbber animation
 * Shows animated logo during page loading
 */
class ThrobberWidget : public QWidget {
    Q_OBJECT

public:
    explicit ThrobberWidget(QWidget* parent = nullptr);
    ~ThrobberWidget() override;

    void startAnimation();
    void stopAnimation();
    bool isAnimating() const { return m_animating; }

    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;

protected:
    void paintEvent(QPaintEvent* event) override;

private slots:
    void nextFrame();

private:
    void loadFrames();

    QVector<QPixmap> m_frames;
    QTimer* m_timer;
    int m_currentFrame = 0;
    bool m_animating = false;

    static const int FRAME_COUNT = 30;
    static const int FRAME_INTERVAL = 100;  // ms
    static const int THROBBER_SIZE = 40;
};

#endif // THROBBER_WIDGET_H
