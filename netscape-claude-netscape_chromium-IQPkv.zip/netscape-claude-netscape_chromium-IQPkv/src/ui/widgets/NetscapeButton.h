#ifndef NETSCAPE_BUTTON_H
#define NETSCAPE_BUTTON_H

#include <QAbstractButton>
#include <QPixmap>

/**
 * Classic Netscape-style toolbar button
 * Four states: normal, hover, pressed, disabled
 * 3D beveled border in Windows 95 style
 */
class NetscapeButton : public QAbstractButton {
    Q_OBJECT

public:
    explicit NetscapeButton(QWidget* parent = nullptr);

    // Set button graphics for all states
    void setAssets(const QPixmap& normal,
                   const QPixmap& hover,
                   const QPixmap& pressed,
                   const QPixmap& disabled);

    // Set single asset (uses same for all states)
    void setPixmap(const QPixmap& pixmap);

    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;

protected:
    void paintEvent(QPaintEvent* event) override;
    void enterEvent(QEnterEvent* event) override;
    void leaveEvent(QEvent* event) override;

private:
    void paintBorder(QPainter* painter, bool raised);

    QPixmap m_normal;
    QPixmap m_hover;
    QPixmap m_pressed;
    QPixmap m_disabled;

    bool m_hovered = false;
    int m_buttonSize = 40;
    int m_iconSize = 32;
};

#endif // NETSCAPE_BUTTON_H
