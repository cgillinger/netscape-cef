#ifndef NETSCAPE_STYLE_H
#define NETSCAPE_STYLE_H

#include <QProxyStyle>

/**
 * Custom Qt style to replicate classic Netscape/Windows 95 appearance
 */
class NetscapeStyle : public QProxyStyle {
    Q_OBJECT

public:
    NetscapeStyle();

    void drawPrimitive(PrimitiveElement element, const QStyleOption* option,
                       QPainter* painter, const QWidget* widget) const override;

    void drawControl(ControlElement element, const QStyleOption* option,
                     QPainter* painter, const QWidget* widget) const override;

    // Classic colors
    static QColor backgroundColor() { return QColor(192, 192, 192); }
    static QColor highlightLight() { return QColor(255, 255, 255); }
    static QColor highlightDark() { return QColor(128, 128, 128); }
    static QColor borderDark() { return QColor(0, 0, 0); }
    static QColor selectionColor() { return QColor(0, 0, 128); }
    static QColor textColor() { return QColor(0, 0, 0); }
};

#endif // NETSCAPE_STYLE_H
