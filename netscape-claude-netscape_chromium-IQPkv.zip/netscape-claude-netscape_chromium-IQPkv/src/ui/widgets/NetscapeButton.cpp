#include "NetscapeButton.h"

#include <QPainter>
#include <QEnterEvent>

NetscapeButton::NetscapeButton(QWidget* parent)
    : QAbstractButton(parent) {

    setFixedSize(m_buttonSize, m_buttonSize);
    setCursor(Qt::PointingHandCursor);
}

void NetscapeButton::setAssets(const QPixmap& normal,
                                const QPixmap& hover,
                                const QPixmap& pressed,
                                const QPixmap& disabled) {
    m_normal = normal;
    m_hover = hover;
    m_pressed = pressed;
    m_disabled = disabled;
    update();
}

void NetscapeButton::setPixmap(const QPixmap& pixmap) {
    m_normal = pixmap;
    m_hover = pixmap;
    m_pressed = pixmap;
    m_disabled = pixmap;
    update();
}

QSize NetscapeButton::sizeHint() const {
    return QSize(m_buttonSize, m_buttonSize);
}

QSize NetscapeButton::minimumSizeHint() const {
    return QSize(m_buttonSize, m_buttonSize);
}

void NetscapeButton::paintEvent(QPaintEvent* event) {
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::SmoothPixmapTransform);

    // Background
    painter.fillRect(rect().adjusted(2, 2, -2, -2), QColor(192, 192, 192));

    // Border
    bool raised = !isDown() && isEnabled();
    paintBorder(&painter, raised);

    // Select appropriate icon
    QPixmap icon;
    if (!isEnabled()) {
        icon = m_disabled;
    } else if (isDown()) {
        icon = m_pressed;
    } else if (m_hovered) {
        icon = m_hover;
    } else {
        icon = m_normal;
    }

    // Draw icon centered
    if (!icon.isNull()) {
        QRect iconRect(0, 0, m_iconSize, m_iconSize);
        iconRect.moveCenter(rect().center());

        // Offset when pressed for tactile feedback
        if (isDown()) {
            iconRect.translate(1, 1);
        }

        painter.drawPixmap(iconRect, icon.scaled(m_iconSize, m_iconSize,
                           Qt::KeepAspectRatio, Qt::SmoothTransformation));
    }
}

void NetscapeButton::paintBorder(QPainter* painter, bool raised) {
    QRect r = rect();

    // Classic Windows 3.1/95 style beveled border
    QColor light = raised ? QColor(255, 255, 255) : QColor(128, 128, 128);
    QColor medium = raised ? QColor(223, 223, 223) : QColor(128, 128, 128);
    QColor dark = raised ? QColor(128, 128, 128) : QColor(255, 255, 255);
    QColor darkest = QColor(0, 0, 0);

    // Outer border - top and left (light when raised)
    painter->setPen(light);
    painter->drawLine(r.left(), r.top(), r.right() - 1, r.top());
    painter->drawLine(r.left(), r.top(), r.left(), r.bottom() - 1);

    // Outer border - bottom and right (dark when raised)
    painter->setPen(darkest);
    painter->drawLine(r.right(), r.top(), r.right(), r.bottom());
    painter->drawLine(r.left(), r.bottom(), r.right(), r.bottom());

    // Inner border - top and left
    painter->setPen(medium);
    painter->drawLine(r.left() + 1, r.top() + 1, r.right() - 2, r.top() + 1);
    painter->drawLine(r.left() + 1, r.top() + 1, r.left() + 1, r.bottom() - 2);

    // Inner border - bottom and right
    painter->setPen(dark);
    painter->drawLine(r.right() - 1, r.top() + 1, r.right() - 1, r.bottom() - 1);
    painter->drawLine(r.left() + 1, r.bottom() - 1, r.right() - 1, r.bottom() - 1);
}

void NetscapeButton::enterEvent(QEnterEvent* event) {
    m_hovered = true;
    update();
    QAbstractButton::enterEvent(event);
}

void NetscapeButton::leaveEvent(QEvent* event) {
    m_hovered = false;
    update();
    QAbstractButton::leaveEvent(event);
}
