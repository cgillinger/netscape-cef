#ifndef LOCATION_TOOLBAR_H
#define LOCATION_TOOLBAR_H

#include <QWidget>

class QComboBox;
class QLabel;

/**
 * Location bar with URL entry
 * Classic "Location:" label with dropdown combo box
 */
class LocationToolbar : public QWidget {
    Q_OBJECT

public:
    explicit LocationToolbar(QWidget* parent = nullptr);

    void setUrl(const QString& url);
    QString url() const;

signals:
    void urlEntered(const QString& url);

protected:
    void paintEvent(QPaintEvent* event) override;

private slots:
    void onReturnPressed();

private:
    QLabel* m_locationLabel;
    QComboBox* m_urlCombo;
    QStringList m_history;
};

#endif // LOCATION_TOOLBAR_H
