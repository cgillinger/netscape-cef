#include "NetscapeMenuBar.h"
#include "NetscapeMainWindow.h"

#include <QMenu>
#include <QAction>
#include <QApplication>
#include <QMessageBox>

NetscapeMenuBar::NetscapeMenuBar(NetscapeMainWindow* parent)
    : QMenuBar(parent)
    , m_mainWindow(parent) {

    // Classic menu bar styling
    setStyleSheet(
        "QMenuBar {"
        "  background-color: #c0c0c0;"
        "  border-bottom: 1px solid #808080;"
        "  padding: 2px;"
        "}"
        "QMenuBar::item {"
        "  background: transparent;"
        "  padding: 4px 8px;"
        "}"
        "QMenuBar::item:selected {"
        "  background-color: #000080;"
        "  color: white;"
        "}"
        "QMenu {"
        "  background-color: #c0c0c0;"
        "  border: 2px outset #c0c0c0;"
        "}"
        "QMenu::item {"
        "  padding: 4px 20px 4px 20px;"
        "}"
        "QMenu::item:selected {"
        "  background-color: #000080;"
        "  color: white;"
        "}"
        "QMenu::separator {"
        "  height: 2px;"
        "  background: #808080;"
        "  margin: 4px 2px;"
        "}"
    );

    setupFileMenu();
    setupEditMenu();
    setupViewMenu();
    setupGoMenu();
    setupCommunicatorMenu();
    setupHelpMenu();
}

void NetscapeMenuBar::setupFileMenu() {
    m_fileMenu = addMenu("&File");

    QAction* newWindow = m_fileMenu->addAction("&New Window");
    newWindow->setShortcut(QKeySequence::New);

    m_fileMenu->addAction("&Open Page...", QKeySequence::Open);
    m_fileMenu->addAction("Open &File...");
    m_fileMenu->addSeparator();

    m_fileMenu->addAction("&Save As...", QKeySequence::Save);
    m_fileMenu->addSeparator();

    m_fileMenu->addAction("&Print...", QKeySequence::Print, m_mainWindow, &NetscapeMainWindow::onPrint);
    m_fileMenu->addSeparator();

    QAction* quit = m_fileMenu->addAction("E&xit", QKeySequence::Quit);
    connect(quit, &QAction::triggered, qApp, &QApplication::quit);
}

void NetscapeMenuBar::setupEditMenu() {
    m_editMenu = addMenu("&Edit");

    m_editMenu->addAction("&Undo", QKeySequence::Undo);
    m_editMenu->addAction("&Redo", QKeySequence::Redo);
    m_editMenu->addSeparator();

    m_editMenu->addAction("Cu&t", QKeySequence::Cut);
    m_editMenu->addAction("&Copy", QKeySequence::Copy);
    m_editMenu->addAction("&Paste", QKeySequence::Paste);
    m_editMenu->addSeparator();

    m_editMenu->addAction("Select &All", QKeySequence::SelectAll);
    m_editMenu->addSeparator();

    m_editMenu->addAction("&Find in Page...", QKeySequence::Find);
    m_editMenu->addAction("Find A&gain", QKeySequence::FindNext);
    m_editMenu->addSeparator();

    m_editMenu->addAction("Pr&eferences...");
}

void NetscapeMenuBar::setupViewMenu() {
    m_viewMenu = addMenu("&View");

    QAction* reload = m_viewMenu->addAction("&Reload", QKeySequence::Refresh);
    connect(reload, &QAction::triggered, m_mainWindow, &NetscapeMainWindow::onReload);

    m_viewMenu->addSeparator();

    m_viewMenu->addAction("Page &Source");
    m_viewMenu->addAction("Page &Info");
    m_viewMenu->addSeparator();

    QMenu* encoding = m_viewMenu->addMenu("&Character Encoding");
    encoding->addAction("Western (ISO-8859-1)");
    encoding->addAction("Unicode (UTF-8)");
    encoding->addAction("Auto-Detect");
}

void NetscapeMenuBar::setupGoMenu() {
    m_goMenu = addMenu("&Go");

    QAction* back = m_goMenu->addAction("&Back", QKeySequence::Back);
    connect(back, &QAction::triggered, m_mainWindow, &NetscapeMainWindow::onBack);

    QAction* forward = m_goMenu->addAction("&Forward", QKeySequence::Forward);
    connect(forward, &QAction::triggered, m_mainWindow, &NetscapeMainWindow::onForward);

    QAction* home = m_goMenu->addAction("&Home");
    home->setShortcut(Qt::ALT | Qt::Key_Home);
    connect(home, &QAction::triggered, m_mainWindow, &NetscapeMainWindow::onHome);

    m_goMenu->addSeparator();
    m_goMenu->addAction("&History");
}

void NetscapeMenuBar::setupCommunicatorMenu() {
    m_communicatorMenu = addMenu("&Communicator");

    m_communicatorMenu->addAction("&Navigator");
    m_communicatorMenu->addAction("&Messenger");
    m_communicatorMenu->addAction("&Address Book");
    m_communicatorMenu->addAction("&Composer");
    m_communicatorMenu->addSeparator();
    m_communicatorMenu->addAction("&Bookmarks");
    m_communicatorMenu->addAction("&History");
}

void NetscapeMenuBar::setupHelpMenu() {
    m_helpMenu = addMenu("&Help");

    m_helpMenu->addAction("&Help Contents");
    m_helpMenu->addAction("&Release Notes");
    m_helpMenu->addSeparator();

    QAction* about = m_helpMenu->addAction("&About Netscape");
    connect(about, &QAction::triggered, [this]() {
        QMessageBox::about(m_mainWindow, "About Netscape",
            "<h2>Netscape Navigator</h2>"
            "<p>Version 4.8-CEF</p>"
            "<p>A recreation of the classic Netscape Navigator browser "
            "using the Chromium Embedded Framework for modern web rendering.</p>"
            "<p>Original Netscape Navigator was created by Netscape Communications Corporation.</p>"
            "<p>This project uses original Netscape graphical assets for educational purposes.</p>"
        );
    });
}
